********************************************************************************
*                                                                              *
* THIS FOLDER CONTAINS SEVERAL SUBROUTINES, 1 SUBROUTINE PER FILE,             *
* THAT MIGHT BE USEFUL TO A USER. BELOW IS A LIST OF FILES IN ALPHABETIC ORDER *
* WITH A SHORT DISCRIBTION:                                                    *
*                                                                              *
********************************************************************************

AAA.F90 - a template with comments in each subroutine;

IQFLUX.F90 - computes fluxes for I and Q;

KSCATMAT.F90 - To restore the phase matrix from coefficients;

LEGPOL.F90 - Ordinary Legendre functions, Pk(x)

PRINT1D.F90 - This subroutine prints a 1D array into a txt file;

PRINT2D.F90 - This subroutine prints a 2D array into a txt file;

READ2D.F90 - This subroutine reads in a 2D array from a specified file;
