02Mar14

********** U-component has different sign. This was expected from previous computations *****************
********** System of coordinates usd in RT3 must be clarified from the paper about RT3  *****************

SCENARIO:

-Atmosphere: Rayleigh, depolarization factor = 0, Tau = 0.3, Single Scattering Albedo = 0.8

-Surface: Lambert, ro = 0.75

-Normalization from RT3: 1/mu0

-View Geometry: 32 Double Gauss nodes (16 per hemisphere), Az = 0:45:180

-Solar Geometry: SZA = 17

-Number of ordinates per HEMIspher: 16

-Fourier moments m = 0, 1, 2

-Full polarization case

-Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	0.1 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
