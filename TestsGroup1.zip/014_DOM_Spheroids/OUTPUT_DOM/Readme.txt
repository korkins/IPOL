SiewertCE, 2000: A discrete-ordinates solution for radiative-transfer models that include polarization effects,
JQSRT, 64, p.227-254.

See Tables 2-9.