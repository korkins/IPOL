14May14

1. Run IPOL using input from Config0, Atmosphere, Surface.
2. Compare your IQUV with the corresponding IQUV_test.txt.