22Feb14

SCIATRAN results were provided by Dr.Vladimir Rozanov (Bremen University), 12Mar13.
The results were used to test code APC and were published in

KorkinSV, LyapustinAI, RozanovVV, JQSRT 127 (2013), 1-11.

*.use files - results in user defined angles.

SCENARIO:

-Atmosphere: Rayleigh, depolarization factor = 0, Tau = 0.1 and 0.5, Single Scattering Albedo = 0.9

-Surface: Ocean, Nakajima-Tanaka model (no wind), refractive index 1.34+0i, wind speed at 10m above the surface U = 1m/s

-Surface slopes: Sigma*Sigma = S1*U + S2, where S1 = 5.12D-3, S2 = 3.00D-3

-Number of nodes for azimuth integration of surface (to get Fourier moments): 180

-Normalization from SCIATRAN: pi/mu0

-View Geometry: VZA = 0:10:80 - 9 user defined angles; AZA = 0, 45 - 2 angles

-Solar Geometry: SZA = 60 - 1 angle

-Number of ordinates per HEMIsphere: N = 40 (2N = 80 total)

-Fourier moments m = 0, 1, 2

-Single scattering correction (atmosphere and surface): ON

-Shadows ON

-Polarization in atmosphere ON

-Polarization from surface ON

-Reflected radiances only

-No interpolation was used in the surface BPDF


**********************
*                    *
* TIME (Debug mode): *
*	2.6 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
