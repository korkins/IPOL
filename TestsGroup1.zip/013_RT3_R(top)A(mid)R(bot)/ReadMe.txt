11Apr14

********** U AND V-component has different sign. This was expected from previous computations *****************
********** System of coordinates usd in RT3 must be clarified from the paper about RT3  ***********************
********** The sign of expansion moments is not clear and must be checked again *******************************

SCENARIO:

-Atmosphere: top layer - Rayleigh, middle layer - Aerosol from RT3 (12 moments); bottom layer - pure Rayleigh

- TAU top to bottom: 0.2(R) 0.5(A) 0.3(R)

- SSA top to bottom: 1.0(R) 0.7(A) 0.9(R)
		
-Surface: Lambert, ro = 0.3

-Normalization from RT3: 1/mu0

-View Geometry: Az = 0:45:180, VZA = Nodes as EXTRA angles

-Solar Geometry: SZA = Node

	89.69635773280595333905389320154
	88.411988066229212958003891474257
	86.147715747250820277049026488092
	82.975266473445015814744300455738
	78.98523934677278877537026332475
	74.2767179935678896070827860191
	68.949035578639329890229453091902
	63.096207034535672867060685369874
	56.803900723397755734204921672209
	50.14836811663268488122060266082
	43.196671914522520100704806021717
	36.007687544781155301495708616393
	28.633588130875656987529454703704
	21.121942126010552098589849326459
	13.520 211 212 051 922 718 186 427 170 117 <- ONLY THIS WAS TESTED AGAINST RT3
	5.901309516288952956916227499534


-Number of ordinates per HEMIspher: 16

-Fourier moments m = 0, 1, 2, ... 10

-Full polarization case

-Reflected and transmitted radiances

-Depolarization factor = 0


**********************
*                    *
* TIME (Debug mode): *
*	3.6 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
