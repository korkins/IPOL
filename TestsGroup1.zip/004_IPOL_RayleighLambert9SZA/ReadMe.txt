04Mar14

This test IPOL vs IPOL was performed becuase an error in Lambertian surface has been found and fixed 03Mar14. 

SCENARIO:

-Atmosphere: Rayleigh, depolarization factor = 0, Tau = 0.3, Single Scattering Albedo = 0.8

-Surface: Lambert, ro = 0.75

-Normalization from RT3: 1/mu0

-View Geometry: 32 Double Gauss nodes (16 per hemisphere), Az = 0:45:180

-Solar Geometry: SZA = 17 - IPOL(1) and SZA = 60 50 40 30 45 25 20 17 0 for IPOL(2)

-Number of ordinates per HEMIspher: 16

-Fourier moments m = 0, 1, 2

-Full polarization case

-Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
* 1SZA - 0.1 sec.    *
* 9SZA - 0.1 sec. !! *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
