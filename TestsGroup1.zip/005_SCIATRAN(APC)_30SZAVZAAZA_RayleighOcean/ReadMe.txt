07Mar14

Dr.Vladimir Rozanov (Bremen University) compared the APC results (from folder ..\OUTPUT_SCIATRAN)
with his results and observed an agreement: All-vector-0.pdf and All-vector-180.pdf in the same folder.
Note that in this experiment, APC results were used, NOT the SCIATRAN data!

**************************************************************************

	A user must allocate enough memeory to run this test:
        SZA x (VZA + GAUSS NODES) x AZA = 30 x (30 + 80) x 30
        Some arrays are really big.  

**************************************************************************

SCENARIO:

-Atmosphere: Rayleigh, depolarization factor = 0, Tau = 0.25, Single Scattering Albedo = 1.0

-Surface: Ocean, Nakajima-Tanaka model (no wind), refractive index 1.33+0i, wind speed at 10m above the surface U = 2m/s

-Surface slopes: Sigma*Sigma = S1*U + S2, where S1 = 5.12D-3, S2 = 3.00D-3

-Number of nodes for azimuth integration of surface (to get Fourier moments): 180

-Normalization from SCIATRAN: pi/mu0

-View Geometry: 30 viewing angles:
 0.0001, 3.0,  6.0,  9.0, 12.0, 15.0, 18.0, 21.0, 24.0, 27.0, 
 30.0,  33.0, 36.0, 39.0, 42.0, 45.0, 48.0, 51.0, 54.0, 57.0,
 60.0,  63.0, 66.0, 69.0, 72.0, 75.0, 78.0, 81.0, 84.0, 87.0

-Solar Geometry: SZA = 30 - 1 angle. But IPOL was run for SZA=VZA - 30 angles

-Azimuths: AZA = VZA - 30 angles, exept for AZA(1) = 0, AZA(30) = 180, which are the only analyzed azimuths

**************************************************************************

	A user must allocate enough memeory to run this test!!!

**************************************************************************

-Number of ordinates per HEMIsphere: N = 40 (2N = 80 total)

-Fourier moments m = 0, 1, 2

-Single scattering correction (atmosphere and surface): ON

-Shadows ON

-Polarization in atmosphere ON

-Polarization from surface ON

-Reflected radiances only

-No interpolation was used in the surface BPDF


**********************
*                    *
* TIME (Debug mode): *
*	7.2 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
