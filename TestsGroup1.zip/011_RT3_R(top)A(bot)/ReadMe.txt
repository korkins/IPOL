05Apr14

********** U AND V-component has different sign. This was expected from previous computations *****************
********** System of coordinates usd in RT3 must be clarified from the paper about RT3  ***********************
********** The sign of expansion moments is not clear and must be checked again *******************************

SCENARIO:

-Atmosphere: top layer - pure Rayleigh, Tau=0.3; bottom layer - Aerosol from RT3 (12 moments), Tau = 0.5, Single Scattering Albedo = 0.9
		
-Surface: black

-Normalization from RT3: 1/mu0

-View Geometry: Az = 0:45:180, VZA = Regular Nodes (no extra VZA)

-Solar Geometry: SZA = 50.0

-Number of ordinates per HEMIspher: 16

-Fourier moments m = 0, 1, 2, ... 10

-Full polarization case

-Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	0.5 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
