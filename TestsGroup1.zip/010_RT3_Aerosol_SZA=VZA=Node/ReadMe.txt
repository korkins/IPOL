03Apr14

********** U AND V-component has different sign. This was expected from previous computations *****************
********** System of coordinates usd in RT3 must be clarified from the paper about RT3  ***********************
********** The sign of expansion moments is not clear and must be checked again *******************************

SCENARIO:

-Atmosphere: Aerosol from RT3 (12 moments), Tau = 0.5, Single Scattering Albedo = 0.9

-Surface: black

-Normalization from RT3: 1/mu0

-View Geometry: Az = 0:45:180, EXTRA VZA = Nodes (i.e., Nodes were computed twice with Gauss (regular nodes) and Zero (extra VZA) weights!!):

mu                         EXTRA VZA, degrees
0.994700467495825           5.901309516288952956916227499534
0.972287511536616          13.520211212051922718186427170117
0.932815601193916          21.121942126010552098589849326459
0.877702204177502          28.633588130875656987529454703704
0.808938122201322          36.007687544781155301495708616393
0.729008388828614          43.196671914522520100704806021717
0.640801775389629          50.14836811663268488122060266082
0.547506254918819          56.803900723397755734204921672209
0.452493745081181          63.096207034535672867060685369874
0.359198224610371          68.949035578639329890229453091902
0.270991611171386          74.2767179935678896070827860191
0.191061877798678          78.98523934677278877537026332475
0.122297795822499          82.975266473445015814744300455738
6.718439880608412E-002     86.147715747250820277049026488092
2.771248846338370E-002     88.411988066229212958003891474257
5.299532504175031E-003     89.69635773280595333905389320154


-Solar Geometry: SZA = 63.096 207 034 535 672 867 060 685 369 874 = VZA = NODE

-Number of ordinates per HEMIspher: 16

-Fourier moments m = 0, 1, 2, ... 10

-Full polarization case

-Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	1.2 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
