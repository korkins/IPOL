10Mar14

Compared with the Invariant Imbedding method: Mishchenko MI JQSRT(1990) V43 N2 P163 

It is not totally clear from the paper how to compute Tau-profile. Only the case
of SSA=1.0 (table 3, page 169)

SCENARIO:

-Atmosphere: Rayleigh, depolarization factor = 0, Tau = 1.0, Single Scattering Albedo = 1.0 -> 0.99999999 (IPOL)

-Surface: black

-Normalization: pi

-View Geometry: mu = 0.05 0.1:0.1:1.0 - 11 angles; ; AZA = 0, 90, 180

-Solar Geometry: mu0 = 0.9 - 1 angle

-Number of ordinates per HEMIsphere: N = 20 (2N = 40 total) - see page 171, after Eq.(69), parameter n*

-Fourier moments m = 0, 1, 2

-Single scattering correction (atmosphere and surface): ON

-Polarization in atmosphere ON

-Reflected radiances only


*********************
*                   *
* TIME:             * 
*	16.5 sec.   *
*      (100 layers) *
*                   *
*********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
