Garcia RDM, and Siewert CE, 1989: The F_N method for radiative transfer models that include polarization effects,
JQSRT, 41, 2, pp.17-145.

See Tables 3-10.