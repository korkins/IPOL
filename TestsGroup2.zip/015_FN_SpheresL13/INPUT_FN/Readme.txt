Garcia RDM, and Siewert CE, 1989: The F_N method for radiative transfer models that include polarization effects,
JQSRT, 41, 2, pp.17-145.

*** Case L=13 ***

See page Section "7.Numerical Results", p.138, for detailed explanation of the scenario.

The phase matrix expansion coefficients, not in the notation used by IPOL yet easily convertable, are given in
Vestrucci P and Siewert CE, 1984: A numerical evaluation of an analytical representation of the components in a
Fourier decomposition of the phase matrix for the scattering of polarized light,
JQSRT, 31, 2, pp.177-183. See page 180, Table 4.

Relation between the above mentioned coefficients and the ones used in IPOL can be found in
de Rooij WA and van der Stap CCAH, 1984: Expansion of Miew scattering matrices in generalized spherical functions,
Astron.Astroph., 131, pp.237-248. See Eq.(88) p.243.
