SiewertCE, 2000: A discrete-ordinates solution for radiative-transfer models that include polarization effects,
JQSRT, 64, pp.227-254.

See page 247, 2nd paragraph for detailed explanation of the scenario.

The phase matrix moments, in the notation used by IPOL, are given in
Kuik F, de Haan JF, and Hovenier JW, 1992: Benchmark results for single scattering by spheroids,
JQSRT, 47, 6, pp.477-489. See page 482, Table 6.