19May14

SCENARIO:

- Atmosphere: 1 layer with oblate spheroids, no Rayleigh

- TAU = 1

- SSA = 0.951151
		
- Surface: black

- Normalization: pi

- View Geometry: Az = 0, 90, 180. mu = -1, -0.9, ... -0.0, +0.0 0.1, ... 0.9, 1.0

	VZA =
	0.0
	25.84193276316712873516953925951
	36.869897645844021296855612559093
	45.57299599919429627325538775414
	53.130102354155978703144387440907
	60.0
	66.421821521798168895977500580173
	72.542396876277907709753954207555
	78.463040967184512309862628489487
	84.26082952273321368748509109607
	89.999999

- Solar Geometry: mu0 = 0.6, SZA = 53.130102354155978703144387440907

- Number of ordinates per HEMIspher: 16

- Fourier moments m = 0, 1, 2, ... 14

- Full polarization case

- Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	1.2 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
