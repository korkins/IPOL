Wauben WMF, Hovenier JW, 1992: Polarized radiation of an atmosphere containing randomly-oriented spheroids,
JQSRT, V.47, No 6, pp.491-504.

See Tables 17-24.