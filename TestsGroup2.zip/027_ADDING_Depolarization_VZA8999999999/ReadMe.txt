07Jun14

SCENARIO:

- Atmosphere: 2 layers = R(top) + [Rayleigh+Aerosl](bot)

- TAU = [0.1R, 0.1R+0.4A]

- SSA = 1.0 for R and A
		
- Surface: Lambert, ro = 0.1

- Normalization: pi

- View Geometry: Az = 0; mu = -1, -0.8, -0.5, -0.2, -0.0 +0.0, 0.2, 0.5, 0.8, 1.0
                 VZA = 89.99999999 was used for mu = 0.0

- Solar Geometry: mu0 = 0.5

- Number of ordinates per HEMIspher: 32

- Fourier moments m = 0, 1, 2, ... 24

- Full polarization case

- Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	9.2 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
