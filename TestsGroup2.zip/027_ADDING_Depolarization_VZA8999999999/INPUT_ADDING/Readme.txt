Wauben WMF, JF de Haan, JW Hovenier, 1994: A method for computing visible and infrared polarized monochromatic
radiation in panetary atmospheres, Astron.Astroph., V.282, pp.277-290.

See page 284, Section 5, for detailed explanation of the scenario.

The phase matrix moments, in the notation used by IPOL, are given in
de Rooij WA, van der Stap CCAH, 1984: Expansion of Mie scattering matrices in generalized spherical functions,
Astron. Astrophys., V.131, pp.237-248. See page 243, Table 4, Case C.