Wauben WMF, JF de Haan, JW Hovenier, 1994: A method for computing visible and infrared polarized monochromatic
radiation in panetary atmospheres, Astron.Astroph., V.282, pp.277-290.

See tables 1-2, p.285.