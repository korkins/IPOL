31May14

SCENARIO:

- Atmosphere: 1 Rayleigh layer

- TAU = 0.3262

- SSA = 1.0
		
- Surface: black

- Normalization: pi/mu0

- View Geometry: VZA = 0:1:180, excluding 90. AZA=0,90,180

- Solar Geometry: SZA = 60

- Number of ordinates per HEMIspher: 16

- Fourier moments m = 0,1,2

The JQSRT benchmark data were downloaded from http://www.iup.uni-bremen.de/~alexk/ 31-May-14.

**********************
*                    *
* TIME (Debug mode): *
*      ~20.0 hrs.    *
* for N=240 M=400    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
