Refer to Section 3 in

Kokhanovsky A.A. et al., 2010: Benchmark results in vector atmospheric radiative transfer. 
J. Quant. Spectrosc. Radiat Transfer 111, 1931�1946.

for details.