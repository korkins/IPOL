30May14

SCENARIO:

- Atmosphere: 2 layers = R(top) + [Rayleigh+Aerosl](bot)

- TAU = [0.1R, 0.1R+0.4A]

- SSA = 1.0 for R and A
		
- Surface: Lambert, ro = 0.1

- Normalization: pi

- View Geometry: Az = 0, 30. mu = -1, -0.5, -0.1, 0.1, 0.5, 1.0

- Solar Geometry: mu0 = 0.5 & 0.1

- Number of ordinates per HEMIspher: 32

- Fourier moments m = 0, 1, 2, ... 24

- Full polarization case

- Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	8.5 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
