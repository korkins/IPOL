de Haan JF, Bosma PB, Hovenier JW, 1987: The adding method for multiple scattering calculations of polarized light,
Astron.Astroph., V.183, pp.371-391.

See tables 9-12, p.389.