Plass GN, Kattawar GW, Catchings FE, 1973: Matrix operator theory of radiative transfer.
1: Rayleigh Scattering. Appl.Opt., 12(2), pp.314-329.

See p.318, Table 1, Case Tau=16384.