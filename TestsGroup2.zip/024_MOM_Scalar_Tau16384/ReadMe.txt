30May14

SCENARIO:

- Atmosphere: 1 Rayleigh layer

- TAU = 16384

- SSA = 1.0
		
- Surface: black

- Normalization: 1

- View Geometry: Az = 0 mu = -1 ... -0.037850 (see the original paper)

- Solar Geometry: mu0 = 1.0

- Number of ordinates per HEMIspher: 16

- Fourier moments m = 0

- Scalar case = polarization OFF

- Reflected radiances only


**********************
*                    *
* TIME (Debug mode): *
*	0.1 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
