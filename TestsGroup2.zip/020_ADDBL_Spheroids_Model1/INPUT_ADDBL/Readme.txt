Wauben WMF, Hovenier JW, 1992: Polarized radiation of an atmosphere containing randomly-oriented spheroids,
JQSRT, V.47, No 6, pp.491-504.

See page 491, Section 3, for detailed explanation of the scenario.

The phase matrix moments, in the notation used by IPOL, are given in
Kuik F, de Haan JF, and Hovenier JW, 1992: Benchmark results for single scattering by spheroids,
JQSRT, 47, 6, pp.477-489. See page 481, Table 5.