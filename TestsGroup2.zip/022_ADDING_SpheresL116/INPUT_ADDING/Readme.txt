de Haan JF, Bosma PB, Hovenier JW, 1987: The adding method for multiple scattering calculations of polarized light,
Astron.Astroph., V.183, pp.371-391.

See page 388, Section 8, for detailed explanation of the scenario (above and below Eq.(145)).

The phase matrix moments, in the notation used by IPOL, are given in
de Rooij WA, van der Stap CCAH, 1984: Expansion of Mie scattering matrices in generalized spherical functions,
Astron. Astrophys., V.131, pp.237-248. See page 243, Table 4, Case C.