29May14

SCENARIO:

- Atmosphere: 1 layer with spheres, no Rayleigh

- TAU = 1

- SSA = 1.0
		
- Surface: black

- Normalization: pi

- View Geometry: Az = 0, 30. mu = -1, -0.5, -0.1, 0.1, 0.5, 1.0

- Solar Geometry: mu0 = 0.5 & 0.1

- Number of ordinates per HEMIspher: 32

- Fourier moments m = 0, 1, 2, ... 24

- Full polarization case

- Reflected and transmitted radiances


**********************
*                    *
* TIME (Debug mode): *
*	7.9 sec.     *
*                    *
**********************

Libraries: BLAS, LAPACK 3.3.0, not optimized, prebuilt
