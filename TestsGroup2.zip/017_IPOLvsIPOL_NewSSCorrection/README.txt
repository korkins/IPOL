14May14

Several important changes have been made:

1. IQUVDOM does not use KMX any more. Higher expansion coeffieicnts are now
used in the single scattering only. but not in the Fourier decomposition of the SS
radiation. This makes computation of fluxes a bit tricky, that is why ...
2. ... computation of fluxes have been removed from IPOL.

For the test provided in this folder, absolute deviation of IQUV was computed.
I-component before and after the changes was found to be the same (within 6 digits),
QUV components showed ansolute difference no more than 1.0E-8.

See Octave scipt in this folder: testiquv.m